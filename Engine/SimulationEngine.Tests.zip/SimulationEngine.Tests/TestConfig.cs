using Xunit;

// Disable test parallelization across the entire test assembly
[assembly: CollectionBehavior(DisableTestParallelization = true)]
