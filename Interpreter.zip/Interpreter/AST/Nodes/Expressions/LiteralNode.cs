


using Interpreter.AST.Nodes.NonTerminals;

namespace Interpreter.AST.Nodes.Expressions;
public abstract class LiteralNode(int lineNumber) : ExpressionNode(lineNumber)
{

}