using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("AQL.Tests")]
