


namespace Interpreter.SemanticAnalysis
{
    public class InterpretationException(string message) : Exception(message)
    {
    }
}